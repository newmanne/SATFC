#!/bin/sh

export MROOT=$PWD

rm -rf glueminisat
make -C core clean 
make -C simp clean 
 
