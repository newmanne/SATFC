#!/bin/sh

export MROOT=$PWD

make -C simp r
cp simp/glueminisat_release ./glueminisat


 
