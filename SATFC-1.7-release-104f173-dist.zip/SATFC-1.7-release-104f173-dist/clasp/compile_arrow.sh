#!/bin/bash
# Compile clasp3 on the arrow file system
./compile.sh /cs/public/lib/pkg/tbb43_20150316oss/include /cs/public/lib/pkg/tbb43_20150316oss/lib/intel64/gcc4.4
